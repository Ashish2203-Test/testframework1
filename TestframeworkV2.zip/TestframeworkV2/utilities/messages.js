var printResMessages = {

 displayMessages : function(key, statuscode){
    
     switch(statuscode){

        case 200:
            console.log('\t[log] Successfully Executed API : ' +key)
            break;
        case 201:
            console.log('\t[log] Successfully Executed API : ' +key)
            break;
        case 400:
            console.log('\t[log] Doesnt exists or Bad request or Unknown failure for ' +key)
            break;

        case 409:
            console.log('\t[log] Data Already Exists for ' +key)
            break;

        case 204:
            console.log('\t[log] No Response for ' +key);
            break;
        
        case 404:
            console.log('\t[log] No Skill set or Skill to answer for ' +key);
            break;

        case 501:
            console.log ('\t[log] Organization you are trying to delete is not yet impletmented for ' +key);
            break;
        
        case 401:
            console.log('\t[log] Unauthorized for ' +key);
            break;

        case 405:
            console.log('\t[log] Method Not Allowed for ' +key);
            break;

        // case to handle the server start error task
        case 100:
            console.log('\t\t[Error] Error in ' + key);
            break;

     };
 },
};
module.exports.printResMessages = printResMessages;