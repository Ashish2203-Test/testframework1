'use strict';

var utility = require('../utility');
var script  = require('../../scripts/script');

// ** load environment variables ** //
require('dotenv').config();

// get list of test cases to be execute
var testCases = utility.getTestCases();

// execute test script
script.execute(testCases);
