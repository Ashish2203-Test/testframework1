// test cases dependency added
//const test_cases	= require("../test_cases/test_cases.json");
const TestCases     = require("../test_cases/test_case.js");
//const testBucket    = require("../global/testcasebucket.json");
// test data dependency added
var globalvar= require('../global/global-variables.js');
//const test_data	    = require("../test_data/test_data.json");

// all task dependency added
const classes       = require('./methods').actions;

/**
 * This method is respnsible to load TestCases and there corresponding Task 
 * based on the defined in test_cases.json file.
 * Also loading test data from test_data.json and passing into each TestCases
 * and correspong Task.
 * Finally preparing list of TeastCases and passing to caller driver.js 
 * 
 * @returns : List of TestCases
 */

var runfor = (( testcontainer !== 'undefined' )? testcontainer.trim(): globalvar.genericglobal.testcontainer);
var testBucket =globalvar.genericglobal[runfor];


var  getTestCases = function(test_cases, test_data,testcasebuckethonor) {
    var testCases = [];
    test_cases.forEach(function(testcase) {
      //  if(isExecute(testcase)){
        if(isExefromtestbucket(testcase,testcasebuckethonor)){ 
                  var testCasesObj = new TestCases(testcase);
            testcase.tasks.forEach(function(task) {
                if(isExecute(task)){
                    var testData = test_data[testcase.key];
                    var taskData;
                    if(testData) { 
                        var taskKey = (task.subkey? task.key+"-"+task.subkey:task.key);
                        taskData = test_data[testcase.key][taskKey]; 
                    }
                    if(taskData && taskData.data && taskData.data.length > 0){
                        taskData.data.forEach(function name(obj) {
                            obj.api_key = taskData.api_key || testData.api_key; 
                            testCasesObj.addTask(getInstance(task.key, task, obj));
                        })
                    }else{
                        testCasesObj.addTask(getInstance(task.key, task, taskData));
                    }
                }
            });

            testCases.push(testCasesObj);
        }
    });
    return testCases;
}

/**
 * Get new instance of task 
 */
var  getInstance = function(className, task, data) {
    return new classes[className](task, data);   
}

/**
 * Validate to execute the test cases and task 
 */
var isExecute = function(obj) {
   return !obj.execute || (obj.execute && obj.execute.toLowerCase() == 'yes')
}

var isExefromtestbucket=function(obj,testcasebuckethonor){

    if (testcasebuckethonor === true ||(typeof testcasebuckethonor === 'undefined')){
        if (testBucket.length>0){
                             
               if(testBucket.includes(obj.key)){
                
                 return true;
                 } else{
                     return false;
                 }
              }else{
                 return true;
             }
         }else{
     
             return true;
     
         }


}

module.exports.getTestCases = getTestCases;