'use strict';
var chai        = require('chai');
var should      = chai.should();
var expect      = require('chai').expect;
var chaiSubset  = require('chai-subset');

chai.use(chaiSubset);

// validate response status code
var validateStatusCode = function(res, statusCode) {
     res.should.have.status(statusCode); 
    
}


// validate respnse body type as 'string','number', array' or 'object'
var validateBodyType = function(body, type) {
    
     body.should.be.eql(type);
    
}

// validate respnse body length
var validateBodyLength = function(body, length) {
    
    body.length.should.be.eql(length);
   
}

// validate respnse body text
var validateBodyText = function(body, text) {
    
    //var text = body.text;
    if(typeof text === 'string') {
        if(typeof body === 'string'){
            // check response body should be equals to body
            //expect(body).to.have.string(text);
            //changing this expect to should as we need exact match for the string
            body.should.be.eql(text);
        }else if(Array.isArray(body)){
            // check response body should be in array of body
            expect(body).to.include(text);
        }else if(typeof body === 'object'){
            //TO-DO
                        
        }
        
    }else if(Array.isArray(text)) {
        if(typeof body === 'string'){
                // check response body should be in array of body
            expect(text).to.include(body);
        }else if(Array.isArray(body)){
            //TO-DO
            
        }
    }else if(typeof body === 'object'){
            //TO-DO
            
    }   
    
}

// validate sub set of json in respnse body
var validateBodyJSON = function(body, json) {
    if(Array.isArray(body)){
        // check response body should be in array of body
        body.should.containSubset(json);
    }else if(typeof body === 'object'){
        expect(body).to.containSubset(json);

    }
    
}

module.exports.validateStatusCode   = validateStatusCode;
module.exports.validateBodyType     = validateBodyType;
module.exports.validateBodyLength   = validateBodyLength;
module.exports.validateBodyText     = validateBodyText;
module.exports.validateBodyJSON     = validateBodyJSON;