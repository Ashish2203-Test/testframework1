'use strict';


module.exports.actions = {
    // SkillSet task
    AddSkillSet             : require("./skillSet.js").AddSkillSet,
    GetSkillSets            : require("./skillSet.js").GetSkillSets,
    GetSkillSet             : require("./skillSet.js").GetSkillSet,
    RemoveSkillSet          : require("./skillSet.js").RemoveSkillSet,
    BindSkill               : require("./skillSet.js").BindSkill,
    UnbindSkill             : require("./skillSet.js").UnbindSkill,
    GetSpecificLink         : require('./skillSet.js').GetSpecificLink,
    UpdateSpecificLink      : require('./skillSet.js').UpdateSpecificLink,
    LinkedSkillHealthCheck  : require('./skillSet.js').LinkedSkillHealthCheck,    

    // converse task
    Converse                : require("./converse.js").Converse,
    ConverseWithSkillSet    : require("./converse.js").ConverseWithSkillSet,
    ConverseWithSkill       : require("./converse.js").ConverseWithSkill,

    // skill task
    AddSkill                : require("./skill.js").AddSkill,
    UpdateSkill             : require("./skill.js").UpdateSkill,
    RefreshSkill            : require("./skill.js").RefreshSkill,
    GetRegisteredSkills     : require("./skill.js").GetRegisteredSkills,
    RemoveSkill             : require("./skill.js").RemoveSkill,
    GetSkillDescriptor      : require("./skill.js").GetSkillDescriptor,
    GetSkillSetBySkill      : require("./skill.js").GetSkillSetBySkill,
    SkillHealthcheck        : require("./skill.js").SkillHealthcheck,
    BindToSkillSets         : require("./skill.js").BindToSkillSets,
    GetSkillVersion         : require("./skill.js").GetSkillVersion,

    // service task
    RestartApp              : require('./service').RestartApp,

    // Proactivity task
    CheckProactivity        : require('./proactivity').CheckProactivity, 
    AddConnectionIoTP       : require('./proactivity').AddConnectionIoTP,
    DisconnectIoTP          : require('./proactivity').DisconnectIoTP,
    
}