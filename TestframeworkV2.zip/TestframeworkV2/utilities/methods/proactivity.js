'use strict';
var Task = require('./task').Task;
var chai = require('chai');
var chaiHttp = require('chai-http');
var should = chai.should();
var expect = require('chai').expect;
var async = require('async');
var request = require('../http_request.js');

var validation = require('../validation/validation');
var proservice = require('../services/proactivity_service.js');

var respfromConverse;
var respfromIot;

chai.use(chaiHttp);

/* Class to handle the proactivity task */
class AddConnectionIoTP extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.taskObj = taskObj;
        this.testData = testData;
    }

    run() {

        var apiKey = this.testData.mqtt.apiKey;
        var apiToken = this.testData.mqtt.apiToken;
        var http_host = this.testData.mqtt.http_host;
        var iotCredentialsIdentifier = this.testData.mqtt.iotCredentialsIdentifier;
        var mqtt_host = this.testData.mqtt.mqtt_host;
        var mqtt_s_port = this.testData.mqtt.mqtt_s_port;
        var mqtt_u_port = this.testData.mqtt.mqtt_u_port;
        var org = this.testData.mqtt.org;


        return new Promise((resolve, reject) => {

            proservice.connectToIoT(apiKey, apiToken, http_host, iotCredentialsIdentifier, mqtt_host, mqtt_s_port, mqtt_u_port, org).then(function (result) {
                result.status = 200;
                resolve(result);
            }, function (err) {

                reject(err);
            });

        });

    }
}


class DisconnectIoTP extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.taskObj = taskObj;
        this.testData = testData;
    }

    run() {
         return new Promise((resolve, reject) => {
             proservice.disconnectIoT().then(function (result) {
                 result.status=200;
                 console.log("Result from disconnect",result);
                 resolve(result);
             }, function (err) {

                reject(err);
            });
         });
    }
}


/* Class to handle the proactivity task */
class CheckProactivity extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.taskObj = taskObj;
        this.testData = testData;
    }
    /* call converse with all skills api */
    run() {
        var self = this;

        return new Promise((resolve, reject) => {

            proservice.readDataFromIoT().then(function (resultfromIot) {

                if (resultfromIot.text == 'init') {
                    resultfromIot.status = 400;
                }
                else {
                    resultfromIot.status = 200;

                    var key = self.getParameter("input1");
                    respfromConverse = self.getResponse(key);
                }
                respfromIot = resultfromIot;
                resolve(resultfromIot);
            }, function (err) {

                reject(err);
            });

        });

    }

    /**
    * Override the validate method to validate the respnse as per converse api.
    * @param : respnse 
    */
    validateResponse(res) {
        return new Promise((resolve, reject) => {
            try {
                var self = this;
                // check response status code 
               
                validation.validateStatusCode(res, self.getStatusCode());


                if (self.taskObj.key == "CheckProactivity" && respfromIot.status != 400) {
                    validation.validateBodyText(respfromConverse.speech.text, respfromIot.text);
                }


                // check response body
                var body = self.getResponseBody();

                if (body) {
                    if (body.type) {

                        //validating the type of the response from API
                        //  console.log("The response type from API: "+res.response.type);
                        validation.validateBodyType(res.response.type, body.type);

                    }

                    if (body.text) {
                        var text = body.text;

                        if (res.body) {

                            //expect(res.body).to.have.nested.property('speech.text');
                            if (typeof text === 'string') {
                                // check response body should be equals to body
                                expect(res.body["speech"]["text"]).to.have.string(text);
                            } else if (Array.isArray(text)) {
                                // check response body should be in array of body
                                expect(text).to.include(res.body["speech"]["text"]);
                            }
                        } else if (res.response.body) {
                            // console.log("The response text from API: "+res.response.body);
                            validation.validateBodyText(res.response.body, body.text);
                        }

                    }
                    if (body.json) {
                        validation.validateBodyJSON(res.body, body.json);
                    }
                }
                return resolve();
            } catch (err) {
                return reject(err);
            };
        });
    }
}



module.exports.AddConnectionIoTP = AddConnectionIoTP;
module.exports.CheckProactivity = CheckProactivity;
module.exports.DisconnectIoTP = DisconnectIoTP;
