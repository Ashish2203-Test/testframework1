
'use strict';
var Task        = require('./task').Task;
var chai        = require('chai');
var chaiHttp    = require('chai-http');
var should      = chai.should();
var expect      = require('chai').expect;
var async       = require('async');
var request     = require('.//..//http_request.js');

var validation  = require('../validation/validation');

chai.use(chaiHttp);

/* Class to handle the converse task */
class Converse extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.taskObj  = taskObj;
        this.testData = testData;
    }
    /* call converse with all skills api */
    run(){
        var self = this;
        var data = this.testData;
        var requestBody        = data.body;
        var api = '/v2/api/converse';
        
        return new Promise((resolve, reject) => {
            /* run converse after a delay to allow skill - skillSet 
               binding to complete successfully. */ 
            var myVar = setInterval(myTimer, 5000);
            function myTimer() {
                // clear interval
                clearInterval(myVar);
                request.http.post(self.getBaseUrl(), api, {api_key: self.getApiKey()}, requestBody)
                            .then(function(res){
                                self.saveResponse(res.body);
                                return resolve(res);
                            }, function(err){
                                return reject(err);
                            })
            }
        });
    }

    /**
     * Override the validate method to validate the respnse as per converse api.
     * @param : respnse 
     */
    validateResponse(res) {
        return new Promise((resolve, reject) => {
            try{
                var self = this;
                // check response status code 
                validation.validateStatusCode(res, self.getStatusCode());
                
                // check response body
                var body = self.getResponseBody();
                if(body){
                    if(body.type){

                         //validating the type of the response from API
                      //  console.log("The response type from API: "+res.response.type);
                        validation.validateBodyType(res.response.type, body.type);
                        
                    }

                    if(body.text){
                        var text = body.text;

                        if(res.body)
                        {

                            //expect(res.body).to.have.nested.property('speech.text');
                            if(typeof text === 'string') {
                                // check response body should be equals to body
                                expect(res.body["speech"]["text"]).to.have.string(text);
                            }else if(Array.isArray(text)) {
                                // check response body should be in array of body
                                expect(text).to.include(res.body["speech"]["text"]);
                            }
                        }else if(res.response.body)
                        {
                           // console.log("The response text from API: "+res.response.body);
                            validation.validateBodyText(res.response.body, body.text);
                        }

                    }
                    if(body.json){
                        validation.validateBodyJSON(res.body, body.json);
                    }
                }
                return resolve();
            }catch(err){
                return reject(err);
            };
        });
    }
}

/* Class to handle the task to converse with a specific skillSet */
class ConverseWithSkillSet extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.taskObj  = taskObj;
        this.testData = testData;
    }
    /* call converse with a specific skillSet api */
    run(){
        var self = this;
        var data = this.testData;
        var requestBody        = data.body;
        var api  = '/v2/api/skillSets/' + data.skillSet.name + '/converse';

        return new Promise((resolve, reject) => {
            /* run converse after a delay to allow skill - skillSet 
               binding to complete successfully. */ 
            var myVar = setInterval(myTimer, 5000);
            function myTimer() {
                // clear interval
                clearInterval(myVar);
                request.http.post(self.getBaseUrl(), api, {api_key: self.getApiKey()}, requestBody)
                            .then(function(res){
                                self.saveResponse(res.body);
                                return resolve(res);
                            }, function(err){
                                return reject(err);
                            })
            }
        });
    }

    /**
     * Override the validate method to validate the respnse as per converse api.
     * @param : respnse 
     */
    validateResponse(res) {
        return new Promise((resolve, reject) => {
            try{
                var self = this;
                // check response status code 
                validation.validateStatusCode(res, self.getStatusCode());
                
                // check response body
                var body = self.getResponseBody();
                if(body){
                    if(body.type){

                         //validating the type of the response from API
                      //  console.log("The response type from API: "+res.response.type);
                        validation.validateBodyType(res.response.type, body.type);
                        
                    }

                    if(body.text){
                        var text = body.text;

                        if(res.body)
                        {

                            //expect(res.body).to.have.nested.property('speech.text');
                            if(typeof text === 'string') {
                                // check response body should be equals to body
                                expect(res.body["speech"]["text"]).to.have.string(text);
                            }else if(Array.isArray(text)) {
                                // check response body should be in array of body
                                expect(text).to.include(res.body["speech"]["text"]);
                            }
                        }else if(res.response.body)
                        {
                           // console.log("The response text from API: "+res.response.body);
                            validation.validateBodyText(res.response.body, body.text);
                        }

                    }
                    if(body.json){
                        validation.validateBodyJSON(res.body, body.json);
                    }
                }
                return resolve();
            }catch(err){
                return reject(err);
            };
        });
    }
}

/* Class to handle the task to converse with a specific skill */
class ConverseWithSkill extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.taskObj = taskObj;
        this.testData = testData;
    }
    /* call converse with a specific skill api */
    run(){
        var self = this;
        var data = this.testData;
        var requestBody        = data.body;
        var api  = '/v2/api/skills/' + data.skill.name+ '/converse';

        return new Promise((resolve, reject) => {
            /* run converse after a delay to allow skill - skillSet 
               binding to complete successfully. */  
            var myVar = setInterval(myTimer, 5000);
            function myTimer() {
                // clear interval
                clearInterval(myVar);
                request.http.post(self.getBaseUrl(), api, {api_key: self.getApiKey()}, requestBody)
                            .then(function(res){
                                self.saveResponse(res.body);
                                return resolve(res);
                            }, function(err){
                                return reject(err);
                            })
            }
        });
    }

    /**
     * Override the validate method to validate the respnse as per converse api.
     * @param : respnse 
     */
    validateResponse(res) {
        return new Promise((resolve, reject) => {
            try{
                var self = this;
                // check response status code 
                validation.validateStatusCode(res, self.getStatusCode());
                
                // check response body
                var body = self.getResponseBody();
                if(body){
                    if(body.type){
                         //validating the type of the response from API
                        validation.validateBodyType(res.response.type, body.type);                        
                    }

                    if(body.text){
                        var text = body.text;

                        if(res.body)
                        {

                            //expect(res.body).to.have.nested.property('speech.text');
                            if(typeof text === 'string') {
                                // check response body should be equals to body
                                expect(res.body["speech"]["text"]).to.have.string(text);
                            }else if(Array.isArray(text)) {
                                // check response body should be in array of body
                                expect(text).to.include(res.body["speech"]["text"]);
                            }
                        }else if(res.response.body)
                        {
                            validation.validateBodyText(res.response.body, body.text);
                        }

                    }
                    if(body.json){
                        validation.validateBodyJSON(res.body, body.json);
                    }
                }
                return resolve();
            }catch(err){
                return reject(err);
            };
        });
    }
}

module.exports.Converse              = Converse;
module.exports.ConverseWithSkillSet  = ConverseWithSkillSet;
module.exports.ConverseWithSkill     = ConverseWithSkill;


