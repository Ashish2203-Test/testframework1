'use strict';


var validation  = require('../validation/validation');
var globals =require('../../global/global-variables.js');
/* Base class */

class Task {
   constructor(taskObj, testData) {
        this.testData   = testData;
        this.taskObj    = taskObj;
        this.baseUrl    =   url //((!url) ?  globals.genericglobal.___ENVIRONMENT___ : url);  // 'https://test-sagan-hub.mybluemix.net'; //http://localhost:10010'; //https://test-sagan-hub.mybluemix.net'; //http://localhost:10010'; //http://10.51.237.48:10010'; //';
        this.apiKey     =  key //((typeof key !== 'undefined') ? key: globals.genericglobal.__Key__);   // '2f3db319-3525-748b-ec1d-74aecc07b861'; //process.env.API_KEY';//2f3db319-3525-748b-ec1d-74aecc07b861'; //process.env.API_KEY;
        this.testCase   = null;
    } 
    /** Set testCase object */
    setTestCase(testCase) {
        this.testCase = testCase;
    }

    /** Get testCase object */
    getTestCase() {
        return this.testCase;
    }

    /** Save task response to test case level */
    saveResponse(res) {
        var self = this;
        var flag = this.taskObj.saveresponse;
        if(flag && flag.toLowerCase() == 'yes' && this.testCase){
            this.testCase.setTaskResponse(self.getKey()+self.getSubkey(), res);
        }
    }

    /** Get response based on the task key */
    getResponse(key) {
        if(this.testCase){
            return this.testCase.getTaskResponse(key);
        }
    }

     /** Get the input parameters from  Test Case */
    getParameter(parameter){
        return this.taskObj.params[parameter];

    }

    /** Get api key */
    getApiKey() {
        return (this.testData && this.testData.api_key) || this.apiKey
    }

    /** Get application base url */
    getBaseUrl() {
        return this.baseUrl;
    }

    /** Get task key */
    getKey(){
        return this.taskObj.key;
    }

    /** Get task subkey */
    getSubkey() {
        return this.taskObj.subkey || "";
    }

    /** Get status code  */
    getStatusCode() {
        return this.testData.response.status_code;
    }

    /** Get respnose body */
    getResponseBody(){
        if(this.testData.response.body){
            return this.testData.response.body;
        }
        return;
    }
    /**
     * Validate the api response.
     */
    validateResponse(res) {
        return new Promise((resolve, reject) => {
            try{
                let self = this;
                // validate response status code
                validation.validateStatusCode(res, self.getStatusCode());
                
                let body = self.getResponseBody();
                // validate response body
                if(body) {
                    if(body.type){

                        //validating the type of the response from API
                       // console.log("The response type from API: "+res.response.type);
                        validation.validateBodyType(res.response.type, body.type);
                    }
                    if(body.length){

                        if(res.body)
                        {
                            if(typeof res.body == 'array')
                            {
                               // console.log("The response length from API: "+res.body.length);
                                validation.validateBodyLength(res.body.length, body.length);
                            }else if (typeof res.body == 'string')
                            {
                                //console.log("The response length from API: "+res.body.length);
                                validation.validateBodyLength(res.body.length, body.length);
                            }

                        }else if( res.response && res.response.body)
                        {
                             if(typeof res.response.body == 'array')
                            {
                               // console.log("The response length from API: "+res.response.body.length);
                                validation.validateBodyLength(res.response.body.length, body.length);
                            }else if (typeof res.response.body == 'string')
                            {
                                //console.log("The response length from API: "+res.response.body.length);
                                validation.validateBodyLength(res.response.body.length, body.length);
                            }



                        }

                        
                        
                    }
                    if(body.text){
                          //changes made to get proper attribute of json response
                        
                        if(res.body){
                          //  console.log("The text returned from API response: "+res.body);
                            validation.validateBodyText(res.body, body.text);
                        } else if(res.response.body){
                           // console.log("The text returned from API response: "+res.response.body);
                            validation.validateBodyText(res.response.body, body.text);
                        }
                    }
                    if(body.json){
                      //  console.log("The text returned from API", res.body);
                        validation.validateBodyJSON(res.body, body.json);
                    }
                }

                return resolve();
            }catch(err){
                return reject(err);
            };
        });
    }
}

module.exports.Task          = Task;