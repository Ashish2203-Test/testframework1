'use strict';
var Task        = require('./task').Task;
var chai        = require('chai');
var chaiHttp    = require('chai-http');
var should      = chai.should();
var async       = require('async');
var request     = require('.//..//http_request.js');
var validation  = require('../validation/validation');

chai.use(chaiHttp);

/* Class to handle the add SkillSet task */
class AddSkillSet extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData   = testData;
    }
    /* call add SkillSet api */
    run(){
        var self = this;
        var skillSet = this.testData.skillSet;
        return new Promise((resolve, reject) => {
            var extendedUrl = '/v2/api/skillSets';
            request.http.post(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()}, skillSet)
                        .then(function(res){
                            self.saveResponse(res.body);
                            return resolve(res);
                        }, function(err){
                             return reject(err);
                        })
        });
    }
}

/* Class to handle the get skillSet task */
class GetSkillSets extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
    }
    /* call get all skill sets api */
    run(){
        var self = this;
        return new Promise((resolve, reject) => {
            var extendedUrl = '/v2/api/skillSets';
            request.http.get(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()})
                        .then(function(res){
                            self.saveResponse(res.body);
                            return resolve(res);
                        }, function(err){
                             return reject(err);
                        })
        });
    }
    /**
     * Override the validate method to validate the response as per api.
     * @param : respnse 
     */
    validateResponse(res) {
        return new Promise((resolve, reject) => {
            try{
                var self = this;
                // check response status code 
                validation.validateStatusCode(res, self.getStatusCode());
                
                // check response body
                var body = self.getResponseBody();
                if(body){
                    if(body.type){
                        validation.validateBodyType(res.response.type, body.type);
                        
                    }
                    if(body.json){
                        validation.validateBodyJSON(res.body, body.json);
                    }
                }
                return resolve();
            }catch(err){
                return reject(err);
            };
        });
    }
}

/* Class to handle the get skillSet task */
class GetSkillSet extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData  = testData;
    }
    /* call get specific skill set api */
    run(){
        var self = this;
        var skillSetName = this.testData.skillSet.name;
        return new Promise((resolve, reject) => {
            var extendedUrl = '/v2/api/skillSets/'+skillSetName;
            request.http.get(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()})
                        .then(function(res){
                            self.saveResponse(res.body);
                            return resolve(res);
                        }, function(err){
                            return reject(err);
                        })
        });
    }

    /**
     * Override the validate method to validate the response as per api.
     * @param : respnse 
     */
    validateResponse(res) {
        return new Promise((resolve, reject) => {
            try{
                var self = this;
                // check response status code 
                validation.validateStatusCode(res, self.getStatusCode());
                
                // check response body
                var body = self.getResponseBody();
                if(body){
                    if(body.type){
                        validation.validateBodyType(res.response.type, body.type);
                        
                    }
                    if(body.json){
                        validation.validateBodyJSON(res.body, body.json);
                    }
                }
                return resolve();
            }catch(err){
                return reject(err);
            };
        });
    }
}

/* Class to handle the remove skillSet task */
class RemoveSkillSet extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData = testData;
    }
    /* call remove skillSet api */
    run(){
        var self = this;
        var skillSetName = this.testData.skillSet.name;
        return new Promise((resolve, reject) => {
            var extendedUrl = '/v2/api/skillSets/'+skillSetName;
            request.http.delete(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()})
                        .then(function(res){
                            self.saveResponse(res.body);
                            return resolve(res);
                        }, function(err){
                             return reject(err);
                        })
        });
    }
}

/* Class to handle bind skill to skillSet */
class BindSkill extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData = testData;
    }
    /* call bind skill api */
    run(){
       var self = this;
        var skillSetName = this.testData.skillSet.name;
        var skillData  = this.testData.skillData;
        return new Promise((resolve, reject) => {
            var extendedUrl = '/v2/api/skillSets/'+skillSetName;
            request.http.put(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()}, skillData)
                        .then(function(res){
                            self.saveResponse(res.body);
                            return resolve(res);
                        }, function(err){
                             return reject(err);
                        })
        });
    }
}

/* Class to handle unbind skill from skillSet */
class UnbindSkill extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData = testData;
    }
    /* call unbind skill api */
    run(){
        var self                     = this;
        let skillSetName  = this.testData.skillSet.name;
        let skillName            = this.testData.skill.name;
        return new Promise((resolve, reject) => {
            var extendedUrl = '/v2/api/skillSets/'+skillSetName+'/links/'+skillName;
            request.http.delete(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()})
                        .then(function(res){
                            self.saveResponse(res.body);
                            return resolve(res);
                        }, function(err){
                             return reject(err);
                        })
        });
    }
}

/* Class to handle get health status of all skills bound with an skill set */
class GetSpecificLink extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData    = testData;
    }
    /* call to get health status of all skills bound with an skill set */
    run(){
        var self                     = this;
        let skillSetName  = this.testData.skillSet.name;
        let skillName            = this.testData.skill.name;
        return new Promise((resolve, reject) => {
           var extendedUrl = '/v2/api/skillSets/'+skillSetName+'/links/'+skillName;
           request.http.get(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()})
                        .then(function(res){
                            self.saveResponse(res.body);
                            return resolve(res);
                        }, function(err){
                             return reject(err);
                        })
        });
    }
}

/* Class to handle update skill set task */
class UpdateSpecificLink extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData = testData;
    }
    /* call update skill set api */
    run(){
        var self                     = this;
        let skillSetName  = this.testData.skillSet.name;
        let skillName            = this.testData.skill.name;              
        let data                     = this.testData.data;
        return new Promise((resolve, reject) => {
            var extendedUrl = '/v2/api/skillSets/'+skillSetName+'/links/'+skillName;
            request.http.put(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()}, data)
                        .then(function(res){
                            self.saveResponse(res.body);
                            return resolve(res);
                        }, function(err){
                             return reject(err);
                        })
            });
    }
}

/* Class to handle get health status of all skills bound with an skill set */
class LinkedSkillHealthCheck extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData    = testData;
    }
    /* call to get health status of all skills bound with an skill set */
    run(){
        var self = this;
        var skillSetName      = this.testData.skillSet.name;
        return new Promise((resolve, reject) => {
            var extendedUrl = '/v2/api/skillSets/'+skillSetName+'/health';
            request.http.get(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()})
                        .then(function(res){
                            self.saveResponse(res.body);
                            return resolve(res);
                        }, function(err){
                             return reject(err);
                        })
        });
    }
}

module.exports.AddSkillSet            = AddSkillSet;
module.exports.GetSkillSets           = GetSkillSets;
module.exports.GetSkillSet            = GetSkillSet;
module.exports.RemoveSkillSet         = RemoveSkillSet;
module.exports.BindSkill              = BindSkill;
module.exports.UnbindSkill            = UnbindSkill;
module.exports.GetSpecificLink        = GetSpecificLink;
module.exports.UpdateSpecificLink     = UpdateSpecificLink;
module.exports.LinkedSkillHealthCheck = LinkedSkillHealthCheck;
