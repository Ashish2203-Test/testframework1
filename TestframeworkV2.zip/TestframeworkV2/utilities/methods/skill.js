'use strict';
var Task        = require('./task').Task;
var chai        = require('chai');
var chaiHttp    = require('chai-http');
var should      = chai.should();
var async       = require('async');
var request     = require('.//..//http_request.js');
var expect      = require('chai').expect;
var validation  = require('../validation/validation');

chai.use(chaiHttp);

/* Class to handle the add skill task */
class AddSkill extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData = testData;
    }
    /* call add skill api */
    run(){
        var self   = this;
        var skill  = this.testData.skill;
        return new Promise((resolve, reject) => {
            var extendedUrl = '/v2/api/skills';
            request.http.post(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()}, skill)
                        .then(function(res){
                            self.saveResponse(res.body);
                            return resolve(res);
                        }, function(err){
                             return reject(err);
                        })
            });
    }
    /**
     * Override the validate method to verify that the response contains an skillKey.
     * @param : response 
     */
    validateResponse(res) {
        return new Promise((resolve, reject) => {
            try{
                var self = this;
                // check response status code 
                validation.validateStatusCode(res, self.getStatusCode());
                
                // check response body
                var body = self.getResponseBody();
                if(body.text){
                    var text = body.text;
                    if(res.text)
                    {
                        if(typeof text === 'string') {
                            // check response test should contain the expected text
                            expect(res.text).to.have.string(text);
                        }
                    }
                }
                return resolve();
            }catch(err){
                return reject(err);
            };
        });
    }
}

/* Class to handle the update skill task */
class UpdateSkill extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData = testData;
    }
    /* call update skill api */
    run(){
        var self = this;
        var skillName  = this.testData.skill.name;
        var skill      = this.testData.data;
        return new Promise((resolve, reject) => {
            var extendedUrl = '/v2/api/skills/'+skillName;
        request.http.put(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()}, skill)
            .then(function(res){
                self.saveResponse(res.body);
                return resolve(res);
            }, function(err){
                return reject(err);
            })
    });
    }
        /**
     * Override the validate method to verify that the response contains an skillKey.
     * @param : response 
     */
    validateResponse(res) {
        return new Promise((resolve, reject) => {
            try{
                var self = this;
                // check response status code 
                validation.validateStatusCode(res, self.getStatusCode());
                
                // check response body
                var body = self.getResponseBody();
                if(body.text){
                    var text = body.text;
                    if(res.text)
                    {
                        if(typeof text === 'string') {
                            // check response test should contain the expected text
                            expect(res.text).to.have.string(text);
                        }
                    }
                }
                return resolve();
            }catch(err){
                return reject(err);
            };
        });
    }
}

/* Class to handle the refresh skill task */
class RefreshSkill extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData = testData;
    }
    /* call to refresh skill */
    run(){
        var self = this;
        var skillName      = this.testData.skill.name;
        return new Promise((resolve, reject) => {
            var extendedUrl = '/v2/api/skills/'+skillName+'/refresh';
        request.http.put(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()})
            .then(function(res){
                self.saveResponse(res.body);
                return resolve(res);
            }, function(err){
                return reject(err);
            })
    });
    }
}

/* Class to handle the get all registered skills */
class GetRegisteredSkills extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData     = testData;
    }
    /* call to get all registered skills  */
    run(){
        var self = this;
        return new Promise((resolve, reject) => {
            var extendedUrl = '/v2/api/skills';
            request.http.get(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()})
                        .then(function(res){
                            self.saveResponse(res.body);
                            return resolve(res);
                        }, function(err){
                             return reject(err);
                        })
        });
    }
}

/* Class to handle the delete skill task */
class RemoveSkill extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData = testData;
    }
    /* call to delete skill  */
    run(){
        var self = this;
        var skillName = this.testData.skill.name;
        return new Promise((resolve, reject) => {
            var extendedUrl = '/v2/api/skills/'+skillName;
            request.http.delete(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()})
                        .then(function(res){
                            self.saveResponse(res.body);
                            return resolve(res);
                        }, function(err){
                             return reject(err);
                        })
        });
    }
}

/* Class to handle the get skill descriptor */
class GetSkillDescriptor extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData = testData;
    }
    /* call to get an specific registered skill  */
    run(){
        var self = this;
        var skillName = this.testData.skill.name;
        return new Promise((resolve, reject) => {
            var extendedUrl = '/v2/api/skills/'+skillName;
            request.http.get(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()})
                        .then(function(res){
                            self.saveResponse(res.body);
                            return resolve(res);
                        }, function(err){
                             return reject(err);
                        })
        });
    }
}

/* Class to handle get all skill sets bounded to this skill */
class GetSkillSetBySkill extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData    = testData;
    }
    /* call to get all skill sets bounded to this skill */
    run(){
        var self = this;
        var skillName    = this.testData.skill.name;
        return new Promise((resolve, reject) => {
            var extendedUrl = '/v2/api/skills/'+skillName+'/skillSets';
            request.http.get(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()})
                        .then(function(res){
                            self.saveResponse(res.body);
                            return resolve(res);
                        }, function(err){
                             return reject(err);
                        })
        });
    }
}

/* Class to handle the get health status of this skill */
class SkillHealthcheck extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData    = testData;
    }
    /* call to get health status of this skill */
    run(){
        var self = this;
        var skillName    = this.testData.skill.name;
        return new Promise((resolve, reject) => {
             var extendedUrl = '/v2/api/skills/'+skillName+'/health';
            request.http.get(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()})
                        .then(function(res){
                            self.saveResponse(res.body);
                            return resolve(res);
                        }, function(err){
                             return reject(err);
                        })
        });
    }
}

/* Class to handle bind an skill to several skillSets */
class BindToSkillSets extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData = testData;
    }
    /* call bind skill api */
    run(){
       var self = this;
        var skillName = this.testData.skill.name;
        var skillSets = this.testData.skillSetsData;
        return new Promise((resolve, reject) => {
            var extendedUrl = '/v2/api/skills/'+skillName+'/skillSets';
            request.http.post(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()}, skillSets)
                        .then(function(res){
                            self.saveResponse(res.body);
                            return resolve(res);
                        }, function(err){
                             return reject(err);
                        })
        });
    }
}

/* Class to handle get all skill sets bounded to this skill */
class GetSkillVersion extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData    = testData;
    }
    /* call to get all skill sets bounded to this skill */
    run(){
        var self = this;
        var skillName    = this.testData.skill.name;
        return new Promise((resolve, reject) => {
            var extendedUrl = '/v2/api/skills/'+skillName+'/version';
            request.http.get(self.getBaseUrl(), extendedUrl, {api_key: self.getApiKey()})
                        .then(function(res){
                            self.saveResponse(res.body);
                            return resolve(res);
                        }, function(err){
                             return reject(err);
                        })
        });
    }
}


module.exports.AddSkill              = AddSkill;
module.exports.UpdateSkill           = UpdateSkill;
module.exports.RefreshSkill          = RefreshSkill; 
module.exports.GetRegisteredSkills   = GetRegisteredSkills;
module.exports.RemoveSkill           = RemoveSkill;
module.exports.GetSkillDescriptor    = GetSkillDescriptor;
module.exports.GetSkillSetBySkill    = GetSkillSetBySkill;
module.exports.SkillHealthcheck      = SkillHealthcheck;
module.exports.BindToSkillSets       = BindToSkillSets;
module.exports.GetSkillVersion       = GetSkillVersion;