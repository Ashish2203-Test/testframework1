var Task            = require('./task').Task;
var bluemixService = require("../services/bluemix_service");

/* Class to handle the server restart functionality */
class RestartApp extends Task {
    constructor(taskObj, testData) {
        super(taskObj, testData);
        this.testData    = testData;
    }
    /* call to restart the server */
    run(){
        var self = this;
        var app_guid      = this.testData.app_guid;
        var username      = this.testData.username;
        var password      = this.testData.password;

        return new Promise((resolve, reject) => {

            bluemixService.initialize(username, password) .then(function(result) {
                bluemixService.restartApp(app_guid, result).then(function(res) {
                    bluemixService.isStarted(app_guid, result).then(function (res) {
                        res.status = 200;
                        resolve(res);
                    },function (err) {
                        err.status = 100;
                        reject(err);
                    });
                },function (err) {
                    err.status = err.code;
                    reject(err);
                })  
            },function (err) {
                err.status = 401;
                reject(err);
            });
            
        });
    }

    /**
     * Validate the api response.
     */
    validateResponse(res) {
        return new Promise((resolve, reject) => {
            if(!res.code && !res.error_description){
                resolve(res);
            }else{
                reject(res);
            }
        });
    }
}

module.exports.RestartApp    = RestartApp;