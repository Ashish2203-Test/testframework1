var chai = require('chai');
var Client = require('node-rest-client').Client;
var client = new Client();
var service_api_key_data_script = "grant_type=urn:ibm:params:oauth:grant-type:apikey&apikey=";
var oidc_url = "https://iam.bluemix.net:443/identity/token";
var date= new Date();
var currentTime;
var tokenTime;
var expiretime;
var token;
var difference;

function getToken(key) {
    if(tokenTime==null || (difference > expiretime)){
    return new Promise((resolve, reject) => {
        var args = {
            data: service_api_key_data_script + key,
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "application/json"
            }
        };
        currentTime= date.getHours();
       
        console.log('Generating access token, using WPA service api key. Target IAM:', oidc_url);
        client.post(oidc_url, args, function (data, response) {
            tokenTime= date.getHours();
            expiretime = data.expires_in;
            difference= (currentTime - tokenTime)*3600 ;
            token = data.access_token;
            if (!data.errors && data != null) {
                //return callback(null, data.access_token);
                return resolve(data.access_token);
            }
            if (data.errors) {
                console.log("Unable to generate access token", data);
                return reject(data.errors);
            }
        });
    })
    }
    else{
        return new Promise((resolve, reject) => {
            currentTime= date.getHours();
            difference= (currentTime - tokenTime)*3600 ; 
            return resolve(token);
        })
    }
}

var http = {

    put: function (baseUrl, extendedUrl, key, body) {
        return new Promise((resolve, reject) => {
            if (iamflag.toLowerCase() == "true") {
                getToken(key.api_key).then(function (result) {
                    chai.request(baseUrl)
                        .put(extendedUrl)
                        .set
                        ('Content-Type', 'application/json')
                        .set
                        ('Accept', 'application/json')
                        .set
                        ('Authorization', 'Bearer ' + result)
                        //.query(result)
                        .send(body)
                        .end(function (err, res) {
                            if (err) return reject(err);
                            return resolve(res);
                        })
                }, function (error) {
                    return reject(error);
                });
            }
            else {
                chai.request(baseUrl)
                    .put(extendedUrl)
                    .set('Content-Type', 'application/json')
                    .query(key)
                    .send(body)
                    .end(function (err, res) {
                        if (err) return reject(err);
                        return resolve(res);
                    })
            }
        })
    },

    get: function (baseUrl, extendedUrl, key) {
        return new Promise((resolve, reject) => {
            if (iamflag.toLowerCase() == "true") {
                getToken(key.api_key).then(function (result) {
                    chai.request(baseUrl)
                        .get(extendedUrl)
                        .set
                        ('Content-Type', 'application/json')
                        .set
                        ('Accept', 'application/json')
                        .set
                        ('Authorization', 'Bearer ' + result)
                        //.query(result)
                        .end(function (err, res) {
                            if (err) return reject(err);
                            return resolve(res);
                        })

                }, function (error) {
                    return reject(error);
                });
            }
            else {
                chai.request(baseUrl)
                    .get(extendedUrl)
                    .set('Content-Type', 'application/json')
                    .query(key)
                    .end(function (err, res) {
                        if (err) return reject(err);
                        return resolve(res);
                    })
            }
        })
    },

    delete: function (baseUrl, extendedUrl, key) {
        return new Promise((resolve, reject) => {
            if (iamflag.toLowerCase() == "true") {
                getToken(key.api_key).then(function (result) {
                    chai.request(baseUrl)
                        .delete(extendedUrl)
                        .set
                        ('Content-Type', 'application/json')
                        .set
                        ('Accept', 'application/json')
                        .set
                        ('Authorization', 'Bearer ' + result)
                        //.query(result)
                        .end(function (err, res) {
                            if (err) return reject(err);
                            return resolve(res);
                        })

                }, function (error) {
                    return reject(error);
                });
            }
            else {
                chai.request(baseUrl)
                    .delete(extendedUrl)
                    .set('Content-Type', 'application/json')
                    .query(key)
                    .end(function (err, res) {
                        if (err) return reject(err);
                        return resolve(res);
                    });
            }
        })
    },

    post: function (baseUrl, extendedUrl, key, requestBody) {
        return new Promise((resolve, reject) => {
            if (iamflag.toLowerCase() == "true") {
                    getToken(key.api_key).then(function (result) {
                    chai.request(baseUrl)
                        .post(extendedUrl)
                        .set
                        ('Content-Type', 'application/json')
                        .set
                        ('Accept', 'application/json')
                        .set
                        ('Authorization', 'Bearer ' + result)
                        //.query(result)
                        .send(requestBody)
                        .end(function (err, res) {
                            if (err) return reject(err);
                            return resolve(res);
                        })

                }, function (error) {
                    return reject(error);
                });
            }
            else {
                 chai.request(baseUrl) 
                .post(extendedUrl)
                .set('Content-Type', 'application/json')
                .query(key)
                .send(requestBody)
                .end(function(err, res) {
                    if (err) return reject(err); 
                    return resolve(res);
                });
            }
        })
    }
}

module.exports.http = http;
module.exports.getToken = getToken;