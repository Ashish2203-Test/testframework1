"use-strict";

const endpoint = "https://api.ng.bluemix.net";
//const username = "shrivas9@us.ibm.com";
//const password = "Nitins@0211";
//const app_guid = 'd94b6e7b-1ff8-4268-b7f0-664e880f976e';

const CloudController 	= new (require("cf-nodejs-client")).CloudController(endpoint);
const UsersUAA 			= new (require("cf-nodejs-client")).UsersUAA;
const Apps 				= new (require("cf-nodejs-client")).Apps(endpoint);
const Services 			= new (require("cf-nodejs-client")).Apps(endpoint);

var initialize = function (username, password) {
    return new Promise((resolve, reject) => {
        console.info("\t\t[Info] Starting app ...");
        CloudController.getInfo().then( (result) => {
            UsersUAA.setEndPoint(result.authorization_endpoint);
            return UsersUAA.login(username, password);
        }).then( (result) => {
            console.info("\t\t[Info] Successfully logged in into bluemix ...");
            //result = JSON.parse(result);
            return resolve(result);
        }).catch( (reason) => {
            reason = JSON.parse(reason);
            //console.error("\t\t[Info] Error in login : " , reason);
            return reject(reason);
        });
    });
}

var restartApp = function(app_guid, result) {
    var self = this;
    return new Promise((resolve, reject) => {
        Services.setToken(result);
        Services.stop(app_guid).then( (result) => {
            console.info("\t\t[Info] App stoped successfully...");
            // start service
            return Services.start(app_guid);
        }).then( (result) => {
            console.info("\t\t[Info] App is starting ...");
            return resolve(result);
        }).catch( (reason) => {
            reason = JSON.parse(reason);
            //console.error("\t\t[Info] Error to restart the app : " , reason);
            return reject(reason);
        });
    });
}

var getStats = function(app_guid, result) {
     return new Promise((resolve, reject) => {
        Apps.setToken(result);
        Apps.getStats(app_guid).then( (result) => {
            return resolve(result);
        }).catch( (reason) => {
            reason = JSON.parse(reason);
            return reject(reason);
        });
    });
}

var isStarted = function(app_guid, result) {
     var self = this;
     return new Promise((resolve, reject) => {

         var myVar = setInterval(checkStats, 5000);

         function checkStats() {
                self.getStats(app_guid, result).then(function(res){
                        if(res && res["0"] && res["0"].state === 'RUNNING'){
                            console.info("\t\t[Info] App started successfully ...");
                            clearInterval(myVar);
                            return resolve(res);
                        }else{
                            console.info("\t\t[Info] App is starting ...");
                            //return self.isStarted(app_guid, result);
                        }
                    
                }, function(err){
                    clearInterval(myVar);
                    //console.log("\t\t[Info] Error in status check : ", err)
                    return reject(err);
                })  
         }
       
    });
}

module.exports.initialize       = initialize;
module.exports.restartApp       = restartApp;
module.exports.getStats         = getStats;
module.exports.isStarted        = isStarted;
