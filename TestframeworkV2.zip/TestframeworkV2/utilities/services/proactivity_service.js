var Client = require("ibmiotf");
var response = { "speech": { "text": "init" } };

var appClient;

var connectToIoT = function (api_Key, api_Token, http_host, iotCredentialsIdentifier, mqtt_host, mqtt_s_port, mqtt_u_port, org) {

    return new Promise((resolve, reject) => {
        var iotFoundationCredentials = {
            apiKey: api_Key,
            apiToken: api_Token,
            http_host: http_host,
            iotCredentialsIdentifier: iotCredentialsIdentifier,
            mqtt_host: mqtt_host,
            mqtt_s_port: mqtt_s_port,
            mqtt_u_port: mqtt_u_port,
            org: org
        };
        var res = {};
        //	set IoT foundation credentials
        var organization = iotFoundationCredentials.org;

        var appId = iotFoundationCredentials.iotCredentialsIdentifier + "12345"; //need to create something Unique

        // Unique ID for the application - in the bluemix environment only
        if (process && process.env && process.env.VCAP_APPLICATION) {
            appId = JSON.parse(process.env.VCAP_APPLICATION).application_id;
        }

        var apiKey = iotFoundationCredentials.apiKey;
        var apiToken = iotFoundationCredentials.apiToken;

        //	connect to IoT foundation
        var config = {
            "org": org,
            "id": appId,
            "auth-key": apiKey,
            "auth-token": apiToken
        };

        appClient = new Client.IotfApplication(config);

        // Important - determines if we work locally, or in the bluemix environment.
        // For locally - remove the not(!) from the next condition
        var workingOnLocalDeveloperLaptop = (process && process.env && process.env.VCAP_SERVICES) === undefined;
        //console.log("--workingOnLocalDeveloperLaptop ", workingOnLocalDeveloperLaptop)
        //	Remove the not(!) to work locally
        if (workingOnLocalDeveloperLaptop) {
            appClient.connect();
            console.log("Running on bluemix environment");
        } else {
            appClient.connect();
            console.log("Running on developer laptop");
        }

        appClient.on("connect", function () {
            //appClient.subscribeToDeviceEvents("shieldEngine", "action", "payload");
            //appClient.subscribeToDeviceEvents("ShieldEngine", "action", "reloadJSCode");
            appClient.subscribeToDeviceEvents(); // All events. can filter later
            // appClient.subscribeToDeviceCommands("+", "+", "hazardDetected");
            console.log("Listening to MQTT!");
            resolve(res);
        });

        appClient.on("disconnect", function () {
            console.log("MQTT listener has disconnected!");
        });

        appClient.on("deviceCommand", function (deviceType, deviceId, commandType, formatType, rawpayload, topic) {
            console.log("Inside Device command loop");
            if (commandType === "hazardDetected") {

                var payload = "";
                try {
                    payload = JSON.parse(rawpayload);
                } catch (err) {
                    payload = rawpayload;
                }

                /* maybe just for debugging? */
                console.log("INFO " +
                    "payload command = " + JSON.stringify(payload));
                // Async
                //	}
            }
        });

        appClient.on("deviceEvent", function (deviceType, deviceId, eventType, format, rawpayload) {

           var payload = "";
            try {
                payload = JSON.parse(rawpayload);
            } catch (err) {
                payload = rawpayload;
            }
            console.log("Payload");
            console.log(JSON.stringify(payload));
            response = payload;
            //appClient.disconnect();
            
        });

              
    }, function (err) {

        reject(err);
    });

}



var readDataFromIoT = function () {

    return new Promise((resolve, reject) => {

        var res = {};

        if (response) {

            resolve(response.speech);
            console.log("After resolve");
            response = { "speech": { "text": "init" } };
        }
        else {
            resolve();
        }
        
    }, function (err) {

        reject(err);
    });

}

var disconnectIoT = function(){
    return new Promise((resolve, reject) => {
        var res = {};
         //appClient.on("connect", function () {
                 appClient.disconnect();
      //   });

         resolve(res);

    }, function (err) {

        reject(err);
    });          

}

var DoSomethingSync = function (payload) {
    console.log(payload);
}

var doSomethingElseAsync = function (payload) {
    console.log(payload);
}

module.exports.connectToIoT = connectToIoT;
module.exports.readDataFromIoT = readDataFromIoT;
module.exports.disconnectIoT =  disconnectIoT;

