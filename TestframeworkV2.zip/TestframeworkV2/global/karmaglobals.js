
/* These are global variables for the test case envrinoment .'testcontainer'  must be from either of the three below

production , generic , dev


  
 url= 'https://dev-sagan-hub.mybluemix.net';
 key ='f3da0c14-f229-423f-a48e-89defcfcdf61'; 
 testcontainer=window.__env.testbucket; //window.__env__['testbucketenviron'];   //'generic';
*/


//console.log('param is passed over there in karma globals ',process.env.testbucketenviron);