var genericglobal = {
    
___ENVIRONMENT___: 'sshttps://dev-sagan-hub.mybluemix.net' ,   // "https://test-sagan-hub.mybluemix.net", //
__Key__: 'ssf3da0c14-f229-423f-a48e-89defcfcdf61',//'2f3db319-3525-748b-ec1d-74aecc07b861', //

// Chintamani's key :  f3da0c14-f229-423f-a48e-89defcfcdf61
testcontainer:'production',
production:require('./prodtestbucket.json'),
generic:require('./testcasebucket.json'),
dev:require('./devtestbucket.json'),

}
var executionengine;
var winenv;

/*
if (window !== 'undefined'){
var winenv = window.__env.executionengine;
executionengine=window.__env.executionengine;
} else{
    executionengine=process.argv[1];
    winenv=false;
}

*/
if (process.argv[1]){
    executionengine=process.argv[1];
        } else{
        executionengine=window.__env.executionengine;
    }


if (executionengine.endsWith('mocha')) {
        url= process.env.URL;
        key =process.env.KEY; 
        testcontainer = process.env.testbucketenviron;
        iam = process.env.iam;
        iamflag= process.env.iamflag;
}else{
    url = window.__env.url;
    key = window.__env.key;
    testcontainer = window.__env.testbucket;
    iam = window.__env.iam;
    iamflag = window.__env.iamflag;
}


module.exports.genericglobal=genericglobal;