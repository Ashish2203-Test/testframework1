var chai        = require('chai');
var globals     = require('./global-variables.js');
var async       = require('async');
var should      = require('chai').should();
var httprequest = require('../utilities/http_request.js');
var qry = {api_key:key}; 

/*
    Clean all test test based on provided parameters.
    @param cleanSkillSets : if true clean all skill sets
    @param cleanSkill : if true clean all skills
*/
var cleanAllTestData = function(cleanSkillSets, cleanSkill) {
    beforeEach(function(done){
        this.timeout(150000);
        if (iamflag.toLowerCase() == "true") {
            cleanTestData_IAM(cleanSkillSets, cleanSkill)
                .then(function (res) {
                    done();
                }, function (err) {
                    done();
                });
        }
        else {
            cleanTestData(cleanSkillSets, cleanSkill)
                .then(function (res) {
                    done();
                },function (err){
                    done();
                });
        }
    });
}

var cleanTestData = function(cleanSkillSets, cleanSkill) {
    console.log("  Clean Test Data...");    
    var cleanData = [];
    if(cleanSkillSets) {
        var obj = {
            "getUrl" : "/v2/api/skillSets",
            "deleteURL" : "/v2/api/SkillSets/"
        }
        cleanData.push(obj);
    }
    if(cleanSkill) {
        var obj = {
            "getUrl" : "/v2/api/skills",
            "deleteURL" : "/v2/api/skills/"
        }
        cleanData.push(obj);
    }
    return new Promise((resolve, reject) => {
        async.eachSeries(cleanData, function (data, callback) {
             chai.request(url) 
            .get(data.getUrl)
            .set('Content-Type', 'application/json')
            .query(qry)
            .end(function(err, res) {
                if (err) return reject(err);
                var apivalues = JSON.parse(res.text);
                async.each(apivalues, function (obj, chieldCallback) {
                    if (obj.name) {
                        name = obj.name;
                    }
                    else if (obj.skillSet) {
                        name = obj.skillSet;
                    }
                    var deleteURL = data.deleteURL + name;
                    chai.request(url) 
                        .delete(deleteURL)
                        .set('Content-Type', 'application/json')
                        .query(qry)
                        .end(function(err, res) {
                            chieldCallback();
                        });
                        console.log("\t[log] Deleted : ", name);                    
                }, function (err) {
                    callback();
                });
            })
        }, function (err) {
           return resolve();
        });    
    });
}

var cleanTestData_IAM = function (cleanSkillSets, cleanSkill) {
    console.log("  Clean Test Data ..");
    var cleanData = [];
    if (cleanSkillSets) {
        var obj = {
            "getUrl" : "/v2/api/skillSets",
            "deleteURL" : "/v2/api/SkillSets/"
        }
        cleanData.push(obj);
    }
    if(cleanSkill) {
        var obj = {
            "getUrl" : "/v2/api/skills",
            "deleteURL" : "/v2/api/skills/"
        }
        cleanData.push(obj);
    }
    return new Promise((resolve, reject) => {
          httprequest.getToken(qry.api_key).then(function (result) {
            
            async.eachSeries(cleanData, function (data, callback) {
                chai.request(url)
                    .get(data.getUrl)
                    .set('Content-Type', 'application/json')
                    .set('Accept', 'application/json')
                    .set('Authorization', 'Bearer ' + result)
                    .end(function (err, res) {
                        if (err) return reject(err);
                        var apivalues = JSON.parse(res.text);
                        async.each(apivalues, function (obj, chieldCallback) {
                            
                            if (obj.name) {
                                name = obj.name;
                            }
                            else if (obj.skillSet) {
                                name = obj.skillSet;
                            }
                            var deleteURL = data.deleteURL + name;
                            chai.request(url)
                                .delete(deleteURL)
                                .set('Content-Type', 'application/json')
                                .set('Accept', 'application/json')
                                .set('Authorization', 'Bearer ' + result)
                                .end(function (err, res) {
                                    chieldCallback();
                                });
                                console.log("\t[log] Deleted : ", name);
                        }, function (err) {
                            callback();
                        });
                    })
            }, function (err) {
                return resolve();
            });
        }, function (error) {
            return reject(error);
        });
    });
}

module.exports.cleanAllTestData = cleanAllTestData;