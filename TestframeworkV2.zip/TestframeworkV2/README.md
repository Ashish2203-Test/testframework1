# TestframeworkV2

The automation framework has been changed to support IAM as well as the existing API keys. The command to run the framework has now been changed to: runMocha.bat <URL> <KEY> <TESTCONTAINER/TESTBUCKET> <IAM=IAMFLAG(TRUE/FALSE)>. When the user sets the IAMFlag as true, then the framework will be executed using the user’s Bluemix API key (Implemented under IAM) and if the IAMFlag is set to false then the framework will be executed using the API Key that is passed (same as  current execution). 
The more details for the framework execution are as follows:

1.	Running the framework through existing API keys:
The url is of the environment like the dev or test environment, with the existing API keys where the instance is deployed, the bucket name and IAMFlag set to false.
Ex: runMocha.bat https://dev-sagan-hub.mybluemix.net 0545e915-f2c7-4688-a12b-f45723f20b5b dev iam=false

2.	Running the framework through user’s Bluemix Key (IAM):
The url is of the IAM Sagan hub instance deployed in Bluemix, with the user’s Bluemix API key, the bucket name and IAMFlag set to true. A token is generated for the user’s API key that gives the authorization for accessing the hub.
Ex: runMocha.bat https://dev-sagan-hub-iam.mybluemix.net Sz1X5k-gwMoIMmnnBTb4g10FqHvP9PfjGCCDoEMnsSBL dev iam=true
