#! /bin/bash

echo $1 "  " $2 "  " $3 " " $4 "=" $5

set -u

:"${1:? URL not set or is empty - USAGE:  runMocha <URL> <KEY> <TESTCONTAINER/TESTBUCKET> <IAM=IAMFLAG(TRUE/FALSE)>}"
:"${2:? KEY not set or is empty - USAGE:  runMocha <URL> <KEY> <TESTCONTAINER/TESTBUCKET> <IAM=IAMFLAG(TRUE/FALSE)>}"
:"${3:? testbucket not set or is empty - USAGE:  runMocha <URL> <KEY> <TESTCONTAINER/TESTBUCKET> <IAM=IAMFLAG(TRUE/FALSE)>}"
:"${4:? iamflag not set or is empty - USAGE:  runMocha <URL> <KEY> <TESTCONTAINER/TESTBUCKET> <IAM=IAMFLAG(TRUE/FALSE)>}"
export URL=$1

export KEY=$2

export testbucketenviron=$3

export iam=$4

export iamflag=$5

export dt=`date '+%Y%m%d_%H_%M_%S'`

  export http_proxy=http://ngproxy.persistent.co.in:8080
  export NODE_TLS_REJECT_UNAUTHORIZED=0
  clear
 # node ./node_modules/mocha/bin/mocha scripts/*.js --reporter mochawesome --reporter-options reportFilename=result_$dt.txt --reporter mocha-junit-reporter --reporter-options reportFilename=mochaxml.txt 
 node ./node_modules/mocha/bin/mocha scripts/*.js --reporter mocha-multi-reporters --reporter-options configFile=config.json
 
sleep 5

mv  ./mochawesome-report/mochawesome.html ./mochawesome-report/result_$dt.html
mv  ./mochawesome-report/mochawesome.json ./mochawesome-report/result_$dt.json

echo "Results for html have been renamed, file is  result_$dt.html"
