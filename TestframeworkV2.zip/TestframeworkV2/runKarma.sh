#! /bin/sh

set -u
:"${1:? URL not set or is empty - USAGE:  runMocha <URL> <KEY> <TESTCONTAINER/TESTBUCKET> <IAMFLAG>}"
:"${2:? KEY not set or is empty - USAGE:  runMocha <URL> <KEY> <TESTCONTAINER/TESTBUCKET> <IAMFLAG>}"
:"${3:? testbucket not set or is empty - USAGE:  runMocha <URL> <KEY> <TESTCONTAINER/TESTBUCKET> <IAMFLAG>}"
:"${4:? iamflag not set or is empty - USAGE:  runMocha <URL> <KEY> <TESTCONTAINER/TESTBUCKET> <IAMFLAG>}"
export URL=$1

export KEY=$2

export testbucketenviron=$3

export iamflag=$4

export dt=`date '+%Y%m%d_%H_%M_%S'`

  export http_proxy=http://ngproxy.persistent.co.in:8080
  export NODE_TLS_REJECT_UNAUTHORIZED=0
  clear
  node ./node_modules/karma/bin/karma start karma.conf.js
