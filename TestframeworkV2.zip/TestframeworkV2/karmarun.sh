#!/bin/sh
chmod +x /SAGAN/IBM_Sagan-master-08282017/SaganTest/karmarun.sh
cd /home/sbhorjare/IBM_Sagan/IBM_Sagan-master-08282017/SaganTest/
karma start
