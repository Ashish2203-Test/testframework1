#! /bin/sh

echo "module.exports = require('./lib/http');" > ./node_modules/chai-http/index.js