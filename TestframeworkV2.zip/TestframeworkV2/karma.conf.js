
require('dotenv').config({silent: true});
var d = new Date();
var month= d.getMonth()+1;
module.exports = function(config) {
  
  config.set({
    basePath: '.',
    autoWatch: true,
     
   frameworks: ['env','mocha-debug', 'mocha','browserify'], //,'browserify' , 'requirejs'

    reporters: ['progress', 'html'],
    client: {
      env: {
        testbucket: process.env.testbucketenviron,
        executionengine: process.argv[1],
        url: process.env.URL,
        key: process.env.KEY,
      }
    },

    htmlReporter: {
      outputFile: './reports/result'+d.getFullYear()+""+month+""+d.getDate()+"_"+d.getHours()+"_"+d.getMinutes()+"_"+d.getSeconds()+'.html',
    //   +d.toISOString().replace(/-/g,'').replace(/:/g,'_').replace('T', '_').replace(/\..*$/, '')
      // Optional 
      pageTitle: 'Unit Tests',
      subPageTitle: 'A sample project description',
      groupSuites: true,
      useCompactStyle: true,
      useLegacyStyle: true
    },
    
    files: [
      './global/karmaglobals.js',
      './scripts/script_skill_set.js',
      './scripts/script_skill.js',
      './scripts/script_converse.js',
      './scripts/script_E2E.js'
    ],

    envPreprocessor: [
      process.env.testbucketenviron,
      
    ],
    preprocessors: {
      './global/karmaglobals.js': [ 'env','browserify' ],
      './scripts/script_skill_set.js': [ 'browserify' ],
      './scripts/script_skill.js': [ 'browserify' ],
      './scripts/script_converse.js': [ 'browserify' ],
      './scripts/script_E2E.js': [ 'browserify' ]
    },
 //    browserDisconnectTimeout: 120000,
 //   browserNoActivityTimeout: 120000,

 browserDisconnectTimeout : 10000, // default 2000
 browserDisconnectTolerance : 1, // default 0
 browserNoActivityTimeout : 4*60*1000, //default 10000
 captureTimeout : 4*60*1000 ,//default 60000

    browsers: ['chrome_without_security'],
     customLaunchers: {
         chrome_without_security: {
             base: 'Chrome',
             flags: ['--disable-web-security']
         }
     },
    
    //customDebugFile: 'debug.html',
    
    'plugins' : [
    'karma-mocha',
    'karma-browserify',
    'karma-webpack',
    'karma-env-preprocessor',
    'karma-chai',
    'karma-chrome-launcher',
    'karma-htmlfile-reporter',
    'karma-mocha-debug',
    'karma-env',
    
  ],

    singleRun: true
  });
};
