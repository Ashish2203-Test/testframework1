var express = require('express');
var serveIndex = require('serve-index');
var exec = require('child_process').exec;
var app = express();
var router =express.Router();

/* creating request for http server */
app.get('/', function (req, res) {
    
    var  url= req.query['url'].trim();
    var  key= req.query['key'].trim();
    var  bucket =req.query['bucket'].trim();
    var execengine =req.query['execengine'].trim();
    var iamflag=req.query['iam'].trim();
    var flag="iam";
console.log("URL is ",url,"  Key is ",key," bucket is  ",bucket, " engine is  ",execengine," iam flag ",iamflag );

    res.writeHead(200, {'Content-Type': 'text/plain'});
    var run;
    
const spawn = require('child_process').spawn;
//run = spawn('cmd.exe', ['/c','run.bat',url, key,bucket]);
spawn('bash',['preconfigure.sh']);
if (execengine === 'karma'){
    
     run = spawn('bash', ['runKarma.sh',url, key,bucket,iamflag]);
}else if (execengine === 'mocha'){
 //run = spawn('cmd.exe', ['/c','runMocha.bat',url, key,bucket]);
 run = spawn('bash', ['runMocha.sh',url, key,bucket,flag,iamflag]);
}else{

    res.write("Please specify valid execution framework/engine as karma / mocha (this is case sensetive)");
    
}


if (execengine === 'karma' || execengine==='mocha'){
res.write('Execution started, out put is  --> ');  

run.stdout.on('data', (data) => {
    // console.log(`stdout: ${data}`);
    res.write(data.toString());
});

run.stderr.on('data', (data) => {
   // console.log(`stderr: ${data}`);
   res.write(data.toString());
});

run.on('close', (code) => {
    //console.log(`child process exited with code ${code}`);
    res.write(code.toString());
    res.write(" \n Results for Karma would be at <host>:<port>/karmaresults and \n Results for Mocha can be seen at <host>:<port>/mocharesults/<result_filename>");
    res.end();
   
});
}else{
    res.write("\n");
    res.write(" \t USAGE :  <host>:<port>/?url=<url>&key=<key>&bucket=<bucket>&execengine=<karma/mocha>&iam=false/true");
    res.end();
}

app.use('/mocharesults', serveIndex('mochawesome-report'));
app.use('/mocharesults', express.static('mochawesome-report'));

app.use('/karmaresults', serveIndex('reports'));
app.use('/karmaresults', express.static('reports'));

});
app.listen(8080);




