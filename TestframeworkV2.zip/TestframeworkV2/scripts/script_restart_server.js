'use strict';

var async       = require('async');
var chai        = require('chai');
var should      = chai.should();
var assert      = chai.assert;
var message     = require('../utilities/messages.js');
var utility     = require('../utilities/utility.js');
const test_cases= require("../test_cases/test_cases_restart_server.json");
const test_data = require("../test_data/test_data_restart_server.json");
var commonclean  = require('../global/commoncleanup');

// get list of test cases to be execute
var testCases = utility.getTestCases(test_cases, test_data);
    
    describe('Executing Sagan Test Cases -', function(){
        commonclean.cleanAllTestData(true, true);
        async.eachSeries(testCases, function (testCase, callback) {
            var tasks = testCase.getTasks();
            it(testCase.getDesc(), function(done){
                this.timeout(150000);
                console.log('\t'+ 'Executing : ' +testCase.getDesc());
                async.eachSeries(tasks, function (task, call) {
                        task.run().then(function (res) {
                            message.printResMessages.displayMessages(task.getKey(), res.status);
                            task.validateResponse(res).then(function (res) {
                                task = null;
                                call();
                            },function (error) {
                                console.log('\t' + '\t'+'[error] Validation failed for : ' +task.getKey());
                                task = null;
                                call(error);
                            })
                        }, function(res) {
                            message.printResMessages.displayMessages(task.getKey(), res.status);
                            task.validateResponse(res).then(function (res) {
                                task = null;
                                call();
                            },function (error) {
                                if(error.message){
                                    var err = error.message;
                                    err = err.split("to")
                                    console.log('\t\t[error] to' +err[1] + ' for : ' +task.getKey());
                                }else if(error.description){
                                     console.log('\t\t[error] ' + error.description + ' for : ' +task.getKey());
                                }else if(error.error_description){
                                     console.log('\t\t[error] ' + error.error_description + ' for : ' +task.getKey());
                                }
                                console.log();
                                task = null;
                                call(error);
                            });
                        });
                }, function (err) {
                    if (err) return done(err);
                    done();
                });
            });   
            
            callback();
        }, function (err) {
            
            if (err) return reject(err);
            
        });

    }); 
