
/**
 * Class for test cases
 */
class TestCases {

    constructor(obj) {
        this.tasks = [];
        this.key = obj.key;
        this.desc = obj.desc;
        this.taskResponse = [];
    }
    /** Set task response into testcase level */
    setTaskResponse(taskKey, response) {
        this.taskResponse[taskKey] = response;
    }
    /** Get response of perticular task  */
    getTaskResponse(taskKey) {
        return this.taskResponse[taskKey];
    }

    addTask(task){
        task.setTestCase(this);
        this.tasks.push(task);
    }

    getTasks(){
        return this.tasks
    }
    
    getKey(){ return this.key; }
    getDesc(){ return this.desc; }
}

module.exports = TestCases;